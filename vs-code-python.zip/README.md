"""
📦 Setup — главный файл установщика (setup.exe)
Скачивает и устанавливает VS Code for Python
"""

import os
import sys
import requests
import threading
import json

# Добавляем корневую папку
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from setup.installer_ui import InstallerUI
from setup.create_shortcut import ShortcutCreator


class VSCodeSetup:
    """Установщик VS Code for Python"""

    GITHUB_REPO = "https://github.com/your-repo/vs-code-python"
    DOWNLOAD_URL = "https://github.com/your-repo/vs-code-python/releases/download/v1.0/vs_code_for_python.exe"
    APP_NAME = "VS Code for Python"
    VERSION = "1.0.0"

    def __init__(self):
        self.install_path = os.path.join(os.path.expanduser("~"), "VSCodePython")
        self.downloaded = False

    def check_internet(self):
        """Проверка интернета"""
        try:
            requests.get("https://google.com", timeout=5)
            return True
        except Exception:
            return False

    def download_from_github(self, url, save_path, progress_callback=None):
        """Скачать файл с GitHub"""
        try:
            print(f"📥 Downloading from: {url}")

            response = requests.get(url, stream=True, timeout=30)
            response.raise_for_status()

            total_size = int(response.headers.get('content-length', 0))
            downloaded = 0

            os.makedirs(os.path.dirname(save_path), exist_ok=True)

            with open(save_path, 'wb') as f:
                for chunk in response.iter_content(chunk_size=8192):
                    if chunk:
                        f.write(chunk)
                        downloaded += len(chunk)

                        if progress_callback and total_size > 0:
                            percent = int(downloaded / total_size * 100)
                            progress_callback(percent)

            print(f"✅ Downloaded: {save_path}")
            self.downloaded = True
            return True

        except requests.exceptions.ConnectionError:
            print("❌ No internet connection")
            return False
        except requests.exceptions.HTTPError as e:
            print(f"❌ HTTP Error: {e}")
            return False
        except Exception as ex:
            print(f"❌ Download error: {ex}")
            return False

    def install_local(self):
        """Установить из локальных файлов (без скачивания)"""
        print(f"📦 Installing from local files...")
        print(f"📂 Install path: {self.install_path}")

        # Создаём папку
        os.makedirs(self.install_path, exist_ok=True)

        # Копируем файлы
        src_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        app_dir = os.path.join(src_dir, "app")
        resources_dir = os.path.join(src_dir, "resources")

        # Создаём конфиг установки
        install_info = {
            "app_name": self.APP_NAME,
            "version": self.VERSION,
            "install_path": self.install_path,
            "app_source": app_dir,
            "installed": True
        }

        info_path = os.path.join(self.install_path, "install_info.json")
        with open(info_path, 'w') as f:
            json.dump(install_info, f, indent=4)

        print(f"✅ Installation info saved: {info_path}")
        return True

    def create_desktop_shortcut(self):
        """Создать ярлык на рабочем столе"""
        creator = ShortcutCreator()
        main_path = os.path.join(
            os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
            "app", "main.py"
        )
        return creator.create_shortcut(main_path)

    def uninstall(self):
        """Удалить приложение"""
        import shutil

        print(f"🗑️ Uninstalling {self.APP_NAME}...")

        # Удаляем папку
        if os.path.exists(self.install_path):
            shutil.rmtree(self.install_path)
            print(f"✅ Removed: {self.install_path}")

        # Удаляем ярлык
        creator = ShortcutCreator()
        creator.remove_shortcut()

        print(f"✅ {self.APP_NAME} uninstalled")

    def run_installer_ui(self):
        """Запустить графический установщик"""
        ui = InstallerUI()
        ui.run()

    def run_silent_install(self):
        """Тихая установка без GUI"""
        print(f"🔇 Silent installation of {self.APP_NAME} v{self.VERSION}")
        print(f"=" * 50)

        self.install_local()
        self.create_desktop_shortcut()

        print(f"=" * 50)
        print(f"✅ Installation complete!")
        print(f"📂 Location: {self.install_path}")


def main():
    """Точка входа"""
    if len(sys.argv) > 1:
        arg = sys.argv[1].lower()

        if arg == "--silent":
            setup = VSCodeSetup()
            setup.run_silent_install()

        elif arg == "--uninstall":
            setup = VSCodeSetup()
            setup.uninstall()

        elif arg == "--help":
            print(f"""
⚡ VS Code for Python Setup
{'=' * 40}

Usage:
  python setup.py            # GUI installer
  python setup.py --silent   # Silent install
  python setup.py --uninstall # Uninstall
  python setup.py --help     # Show help
""")
        else:
            print(f"❌ Unknown argument: {arg}")
            print("Use --help for usage info")
    else:
        # GUI установщик
        setup = VSCodeSetup()
        setup.run_installer_ui()


if __name__ == "__main__":
    main()