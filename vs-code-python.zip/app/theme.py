"""
🎨 VS Code Dark Theme — цвета 1 в 1 как в VS Code
"""


class VSCodeTheme:
    """Тёмная тема VS Code"""

    # Основные цвета
    BG_DARK = "#1e1e1e"          # Фон редактора
    BG_SIDEBAR = "#252526"        # Фон боковой панели
    BG_ACTIVITY = "#333333"       # Фон панели активности
    BG_TITLEBAR = "#323233"       # Фон заголовка
    BG_TAB_ACTIVE = "#1e1e1e"    # Активная вкладка
    BG_TAB_INACTIVE = "#2d2d2d"  # Неактивная вкладка
    BG_STATUSBAR = "#007acc"     # Статус бар
    BG_TERMINAL = "#1e1e1e"      # Терминал
    BG_INPUT = "#3c3c3c"         # Поле ввода
    BG_MENU = "#2d2d2d"          # Меню
    BG_HOVER = "#2a2d2e"         # Ховер
    BG_SELECTION = "#264f78"     # Выделение
    BG_LINE_HIGHLIGHT = "#2a2d2e"  # Подсветка строки
    BG_SCROLLBAR = "#424242"     # Скроллбар
    BG_MINIMAP = "#1e1e1e"       # Миникарта
    BG_WELCOME = "#1e1e1e"       # Welcome страница
    BG_EXPLORER_HOVER = "#2a2d2e"  # Ховер в проводнике
    BG_BUTTON = "#0e639c"        # Кнопка

    # Текст
    TEXT_PRIMARY = "#d4d4d4"      # Основной текст
    TEXT_SECONDARY = "#858585"    # Второстепенный
    TEXT_INACTIVE = "#969696"     # Неактивный
    TEXT_WHITE = "#ffffff"        # Белый
    TEXT_ACCENT = "#007acc"       # Акцент
    TEXT_STATUSBAR = "#ffffff"   # Текст статус бара
    TEXT_BUTTON = "#ffffff"      # Текст кнопки

    # Синтаксис
    SYN_KEYWORD = "#569cd6"      # Ключевые слова (if, for, class)
    SYN_STRING = "#ce9178"       # Строки
    SYN_COMMENT = "#6a9955"      # Комментарии
    SYN_FUNCTION = "#dcdcaa"     # Функции
    SYN_CLASS = "#4ec9b0"        # Классы
    SYN_NUMBER = "#b5cea8"       # Числа
    SYN_OPERATOR = "#d4d4d4"     # Операторы
    SYN_DECORATOR = "#dcdcaa"    # Декораторы
    SYN_BUILTIN = "#4fc1ff"      # Встроенные функции
    SYN_SELF = "#569cd6"         # self
    SYN_BOOL = "#569cd6"         # True/False
    SYN_NONE = "#569cd6"         # None
    SYN_IMPORT = "#c586c0"       # import/from
    SYN_BRACKET = "#ffd700"      # Скобки

    # Границы
    BORDER = "#474747"
    BORDER_TAB = "#252526"
    BORDER_ACTIVE = "#007acc"

    # Шрифты
    FONT_CODE = ("Consolas", 14)
    FONT_UI = ("Segoe UI", 11)
    FONT_UI_SMALL = ("Segoe UI", 9)
    FONT_TAB = ("Segoe UI", 10)
    FONT_STATUS = ("Segoe UI", 10)
    FONT_TREE = ("Segoe UI", 11)
    FONT_TERMINAL = ("Consolas", 13)
    FONT_WELCOME_TITLE = ("Segoe UI Light", 28)
    FONT_WELCOME = ("Segoe UI", 12)

    @classmethod
    def get_syntax_colors(cls):
        """Возвращает словарь цветов синтаксиса"""
        return {
            "keyword": cls.SYN_KEYWORD,
            "string": cls.SYN_STRING,
            "comment": cls.SYN_COMMENT,
            "function": cls.SYN_FUNCTION,
            "class": cls.SYN_CLASS,
            "number": cls.SYN_NUMBER,
            "operator": cls.SYN_OPERATOR,
            "decorator": cls.SYN_DECORATOR,
            "builtin": cls.SYN_BUILTIN,
            "self": cls.SYN_SELF,
            "boolean": cls.SYN_BOOL,
            "none": cls.SYN_NONE,
            "import": cls.SYN_IMPORT,
            "bracket": cls.SYN_BRACKET,
        }