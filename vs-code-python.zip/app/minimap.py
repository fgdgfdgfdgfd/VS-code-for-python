"""
🗺️ Minimap — мини-карта кода как в VS Code
"""

import tkinter as tk
from app.theme import VSCodeTheme as T


class Minimap(tk.Canvas):
    """Мини-карта кода (правая полоса)"""

    def __init__(self, parent, text_widget=None):
        super().__init__(
            parent,
            bg=T.BG_MINIMAP,
            width=60,
            highlightthickness=0,
            bd=0
        )

        self.text_widget = text_widget
        self.scale = 0.15  # Масштаб текста
        self.viewport_rect = None
        self.lines_cache = []
        self.visible = True

        # Цвета для мини-карты
        self.colors = {
            "default": "#6e7681",
            "keyword": "#7cafc2",
            "string": "#a3685a",
            "comment": "#5a7a52",
            "function": "#c2b280",
        }

        # Биндим события
        self.bind("<Button-1>", self._on_click)
        self.bind("<B1-Motion>", self._on_drag)
        self.bind("<Enter>", self._on_enter)
        self.bind("<Leave>", self._on_leave)

    def update_minimap(self, content=""):
        """Обновить мини-карту"""
        self.delete("all")
        self.lines_cache.clear()

        if not content:
            return

        lines = content.split("\n")
        y = 2
        char_height = 2  # Высота строки на мини-карте
        char_width = 0.8  # Ширина символа

        for i, line in enumerate(lines):
            if y > self.winfo_height():
                break

            stripped = line.rstrip()
            if not stripped:
                y += char_height
                self.lines_cache.append(("", y))
                continue

            # Определяем цвет строки
            color = self._get_line_color(stripped)

            # Рисуем строку как тонкую линию
            indent = len(line) - len(line.lstrip())
            x_start = 4 + indent * char_width
            x_end = min(4 + len(stripped) * char_width, 56)

            if x_end > x_start:
                self.create_rectangle(
                    x_start, y,
                    x_end, y + char_height,
                    fill=color,
                    outline="",
                    tags="code"
                )

            self.lines_cache.append((stripped, y))
            y += char_height

        # Рисуем видимую область
        self._draw_viewport()

    def _get_line_color(self, line):
        """Определить цвет строки"""
        stripped = line.strip()

        if stripped.startswith("#"):
            return self.colors["comment"]
        elif stripped.startswith(("def ", "class ", "if ", "for ", "while ",
                                   "import ", "from ", "return ", "try:",
                                   "except ", "with ")):
            return self.colors["keyword"]
        elif '"""' in stripped or "'''" in stripped or stripped.startswith(("'", '"')):
            return self.colors["string"]
        elif stripped.startswith("def "):
            return self.colors["function"]
        else:
            return self.colors["default"]

    def _draw_viewport(self):
        """Рисуем прямоугольник видимой области"""
        if self.viewport_rect:
            self.delete(self.viewport_rect)

        if not self.text_widget:
            return

        try:
            # Получаем видимую область
            first_visible = self.text_widget.index("@0,0")
            last_visible = self.text_widget.index(f"@0,{self.text_widget.winfo_height()}")

            first_line = int(first_visible.split(".")[0])
            last_line = int(last_visible.split(".")[0])

            char_height = 2
            y_start = first_line * char_height
            y_end = last_line * char_height

            self.viewport_rect = self.create_rectangle(
                0, y_start,
                60, y_end,
                fill="#ffffff",
                stipple="gray12",
                outline="#ffffff",
                width=1,
                tags="viewport"
            )
        except Exception:
            pass

    def _on_click(self, event):
        """Клик на мини-карте — перейти к строке"""
        if not self.text_widget:
            return

        char_height = 2
        target_line = max(1, int(event.y / char_height))
        self.text_widget.see(f"{target_line}.0")
        self._draw_viewport()

    def _on_drag(self, event):
        """Перетаскивание по мини-карте"""
        self._on_click(event)

    def _on_enter(self, event):
        """Ховер — подсветить"""
        self.config(bg="#252526")

    def _on_leave(self, event):
        """Убрать ховер"""
        self.config(bg=T.BG_MINIMAP)

    def toggle(self):
        """Показать/скрыть"""
        if self.visible:
            self.pack_forget()
            self.visible = False
        else:
            self.pack(side=tk.RIGHT, fill=tk.Y)
            self.visible = True