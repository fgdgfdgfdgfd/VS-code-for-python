"""
💻 Terminal — встроенный терминал как в VS Code
"""

import tkinter as tk
import subprocess
import threading
import os
import sys
from app.theme import VSCodeTheme as T


class Terminal(tk.Frame):
    """Встроенный терминал"""

    def __init__(self, parent):
        super().__init__(parent, bg=T.BG_TERMINAL, height=200)
        self.pack_propagate(False)

        self.process = None
        self.cwd = os.path.expanduser("~")
        self.history = []
        self.history_index = -1
        self.visible = True

        self._create_widgets()

    def _create_widgets(self):
        """Создаём виджеты терминала"""

        # Заголовок терминала
        header = tk.Frame(self, bg=T.BG_TITLEBAR, height=30)
        header.pack(fill=tk.X)
        header.pack_propagate(False)

        # Вкладки терминала
        tabs_frame = tk.Frame(header, bg=T.BG_TITLEBAR)
        tabs_frame.pack(side=tk.LEFT, padx=10)

        terminal_tab = tk.Label(
            tabs_frame,
            text="💻 TERMINAL",
            bg=T.BG_TITLEBAR,
            fg=T.TEXT_PRIMARY,
            font=("Segoe UI", 9, "bold")
        )
        terminal_tab.pack(side=tk.LEFT, padx=5, pady=5)

        for tab_text in ["📊 OUTPUT", "🐛 DEBUG CONSOLE", "❗ PROBLEMS"]:
            tab = tk.Label(
                tabs_frame,
                text=tab_text,
                bg=T.BG_TITLEBAR,
                fg=T.TEXT_SECONDARY,
                font=("Segoe UI", 9)
            )
            tab.pack(side=tk.LEFT, padx=5, pady=5)

        # Кнопки справа
        btns_frame = tk.Frame(header, bg=T.BG_TITLEBAR)
        btns_frame.pack(side=tk.RIGHT, padx=5)

        for emoji in ["➕", "🗑️", "⬆️", "✕"]:
            btn = tk.Label(
                btns_frame,
                text=emoji,
                bg=T.BG_TITLEBAR,
                fg=T.TEXT_SECONDARY,
                font=("Segoe UI", 10),
                cursor="hand2"
            )
            btn.pack(side=tk.LEFT, padx=3, pady=5)
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg=T.BG_HOVER))
            btn.bind("<Leave>", lambda e, b=btn: b.config(bg=T.BG_TITLEBAR))

        # Область вывода
        self.output = tk.Text(
            self,
            bg=T.BG_TERMINAL,
            fg=T.TEXT_PRIMARY,
            font=T.FONT_TERMINAL,
            insertbackground=T.TEXT_PRIMARY,
            selectbackground=T.BG_SELECTION,
            relief="flat",
            wrap=tk.WORD,
            padx=10,
            pady=5
        )
        self.output.pack(fill=tk.BOTH, expand=True)

        # Тег для разных цветов
        self.output.tag_configure("prompt", foreground="#6a9955")
        self.output.tag_configure("error", foreground="#f44747")
        self.output.tag_configure("info", foreground="#569cd6")
        self.output.tag_configure("path", foreground="#dcdcaa")

        # Начальное сообщение
        self.output.insert(tk.END, "Windows PowerShell\n", "info")
        self.output.insert(tk.END, "Copyright (C) Microsoft Corporation.\n\n", "info")
        self._show_prompt()

        # Биндим ввод
        self.output.bind("<Return>", self._on_enter)
        self.output.bind("<Up>", self._history_up)
        self.output.bind("<Down>", self._history_down)

    def _show_prompt(self):
        """Показать промпт"""
        short_path = self.cwd.replace(os.path.expanduser("~"), "~")
        self.output.insert(tk.END, f"PS {short_path}> ", "prompt")
        self.output.mark_set("prompt_end", "end-1c")
        self.output.see(tk.END)

    def _on_enter(self, event):
        """Обработка Enter"""
        # Получаем введённую команду
        line = self.output.get("prompt_end", "end-1c").strip()
        self.output.insert(tk.END, "\n")

        if line:
            self.history.append(line)
            self.history_index = len(self.history)
            self._execute_command(line)
        else:
            self._show_prompt()

        return "break"

    def _execute_command(self, command):
        """Выполнить команду"""
        # Встроенные команды
        if command.strip().lower() == "clear" or command.strip().lower() == "cls":
            self.output.delete("1.0", tk.END)
            self._show_prompt()
            return

        if command.strip().lower().startswith("cd "):
            path = command.strip()[3:].strip()
            try:
                if path == "~":
                    path = os.path.expanduser("~")
                new_path = os.path.abspath(os.path.join(self.cwd, path))
                if os.path.isdir(new_path):
                    self.cwd = new_path
                else:
                    self.output.insert(tk.END, f"❌ Directory not found: {path}\n", "error")
            except Exception as ex:
                self.output.insert(tk.END, f"❌ Error: {ex}\n", "error")
            self._show_prompt()
            return

        # Выполняем в отдельном потоке
        thread = threading.Thread(target=self._run_process, args=(command,), daemon=True)
        thread.start()

    def _run_process(self, command):
        """Запускаем процесс"""
        try:
            self.process = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                cwd=self.cwd,
                text=True
            )
            stdout, stderr = self.process.communicate(timeout=30)

            if stdout:
                self.output.insert(tk.END, stdout)
            if stderr:
                self.output.insert(tk.END, stderr, "error")

        except subprocess.TimeoutExpired:
            self.process.kill()
            self.output.insert(tk.END, "❌ Process timed out\n", "error")
        except Exception as ex:
            self.output.insert(tk.END, f"❌ Error: {ex}\n", "error")
        finally:
            self.process = None
            self.output.after(0, self._show_prompt)

    def _history_up(self, event):
        """История вверх"""
        if self.history and self.history_index > 0:
            self.history_index -= 1
            self._replace_input(self.history[self.history_index])
        return "break"

    def _history_down(self, event):
        """История вниз"""
        if self.history_index < len(self.history) - 1:
            self.history_index += 1
            self._replace_input(self.history[self.history_index])
        else:
            self.history_index = len(self.history)
            self._replace_input("")
        return "break"

    def _replace_input(self, text):
        """Заменить текущий ввод"""
        self.output.delete("prompt_end", "end-1c")
        self.output.insert("prompt_end", text)

    def toggle(self):
        """Показать/скрыть терминал"""
        if self.visible:
            self.pack_forget()
            self.visible = False
        else:
            self.pack(side=tk.BOTTOM, fill=tk.X)
            self.visible = True

    def run_file(self, filepath):
        """Запустить Python файл"""
        python = sys.executable
        self.output.insert(tk.END, f"\n▶ Running: {filepath}\n", "info")
        self._execute_command(f'"{python}" "{filepath}"')