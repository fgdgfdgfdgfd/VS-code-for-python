"""
📂 File Explorer — проводник файлов как в VS Code
"""

import tkinter as tk
import os
from app.theme import VSCodeTheme as T


class FileExplorer(tk.Frame):
    """Проводник файлов (левая панель)"""

    def __init__(self, parent, on_file_open=None):
        super().__init__(parent, bg=T.BG_SIDEBAR, width=250)
        self.pack_propagate(False)

        self.on_file_open = on_file_open
        self.current_folder = None
        self.tree_items = {}

        self._create_widgets()

    def _create_widgets(self):
        """Создаём виджеты"""

        # Заголовок EXPLORER
        header = tk.Frame(self, bg=T.BG_SIDEBAR, height=35)
        header.pack(fill=tk.X)
        header.pack_propagate(False)

        tk.Label(
            header,
            text="  EXPLORER",
            bg=T.BG_SIDEBAR,
            fg=T.TEXT_SECONDARY,
            font=("Segoe UI", 9, "bold"),
            anchor="w"
        ).pack(side=tk.LEFT, fill=tk.X, padx=10, pady=8)

        # Кнопки в заголовке
        btns_frame = tk.Frame(header, bg=T.BG_SIDEBAR)
        btns_frame.pack(side=tk.RIGHT, padx=5)

        for emoji in ["📄", "📁", "🔄"]:
            btn = tk.Label(
                btns_frame,
                text=emoji,
                bg=T.BG_SIDEBAR,
                fg=T.TEXT_SECONDARY,
                font=("Segoe UI", 10),
                cursor="hand2"
            )
            btn.pack(side=tk.LEFT, padx=2)
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg=T.BG_HOVER))
            btn.bind("<Leave>", lambda e, b=btn: b.config(bg=T.BG_SIDEBAR))

        # Скролл + список файлов
        self.canvas = tk.Canvas(
            self,
            bg=T.BG_SIDEBAR,
            highlightthickness=0,
            bd=0
        )
        self.scrollbar = tk.Scrollbar(
            self,
            orient=tk.VERTICAL,
            command=self.canvas.yview,
            bg=T.BG_SCROLLBAR,
            troughcolor=T.BG_SIDEBAR,
            width=10
        )
        self.files_frame = tk.Frame(self.canvas, bg=T.BG_SIDEBAR)

        self.files_frame.bind(
            "<Configure>",
            lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all"))
        )
        self.canvas.create_window((0, 0), window=self.files_frame, anchor="nw")
        self.canvas.configure(yscrollcommand=self.scrollbar.set)

        self.canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Колесо мыши
        self.canvas.bind_all("<MouseWheel>",
                             lambda e: self.canvas.yview_scroll(-1 * (e.delta // 120), "units"))

    def open_folder(self, folder_path):
        """Открыть папку"""
        self.current_folder = folder_path

        # Очищаем
        for widget in self.files_frame.winfo_children():
            widget.destroy()
        self.tree_items.clear()

        # Название папки
        folder_name = os.path.basename(folder_path).upper()
        folder_label = tk.Label(
            self.files_frame,
            text=f"  📂 {folder_name}",
            bg=T.BG_SIDEBAR,
            fg=T.TEXT_PRIMARY,
            font=("Segoe UI", 10, "bold"),
            anchor="w"
        )
        folder_label.pack(fill=tk.X, padx=5, pady=(5, 2))

        # Строим дерево
        self._build_tree(folder_path, self.files_frame, level=1)

    def _build_tree(self, path, parent_frame, level=0):
        """Рекурсивно строим дерево файлов"""
        try:
            items = sorted(os.listdir(path))
        except PermissionError:
            return

        # Сначала папки, потом файлы
        dirs = [i for i in items if os.path.isdir(os.path.join(path, i)) and not i.startswith('.')]
        files = [i for i in items if os.path.isfile(os.path.join(path, i)) and not i.startswith('.')]

        for dirname in dirs:
            full_path = os.path.join(path, dirname)
            self._add_folder_item(parent_frame, dirname, full_path, level)

        for filename in files:
            full_path = os.path.join(path, filename)
            self._add_file_item(parent_frame, filename, full_path, level)

    def _add_folder_item(self, parent, name, full_path, level):
        """Добавить папку в дерево"""
        indent = "    " * level
        expanded = False

        container = tk.Frame(parent, bg=T.BG_SIDEBAR)
        container.pack(fill=tk.X)

        children_frame = tk.Frame(parent, bg=T.BG_SIDEBAR)

        label = tk.Label(
            container,
            text=f"{indent}▶ 📁 {name}",
            bg=T.BG_SIDEBAR,
            fg=T.TEXT_PRIMARY,
            font=T.FONT_TREE,
            anchor="w",
            cursor="hand2"
        )
        label.pack(fill=tk.X, padx=5, pady=1)

        def toggle(event=None):
            nonlocal expanded
            if expanded:
                children_frame.pack_forget()
                label.config(text=f"{indent}▶ 📁 {name}")
                expanded = False
            else:
                children_frame.pack(fill=tk.X, after=container)
                if not children_frame.winfo_children():
                    self._build_tree(full_path, children_frame, level + 1)
                label.config(text=f"{indent}▼ 📂 {name}")
                expanded = True

        label.bind("<Button-1>", toggle)
        label.bind("<Enter>", lambda e: label.config(bg=T.BG_EXPLORER_HOVER))
        label.bind("<Leave>", lambda e: label.config(bg=T.BG_SIDEBAR))

    def _add_file_item(self, parent, name, full_path, level):
        """Добавить файл в дерево"""
        indent = "    " * level

        ext = os.path.splitext(name)[1].lower()
        icons = {
            ".py": "🐍", ".js": "📜", ".html": "🌐",
            ".css": "🎨", ".json": "📋", ".md": "📝",
            ".txt": "📄", ".xml": "📰", ".gitignore": "🔀",
            ".yml": "⚙️", ".yaml": "⚙️", ".ini": "🔧",
        }
        icon = icons.get(ext, "📄")

        label = tk.Label(
            parent,
            text=f"{indent}   {icon} {name}",
            bg=T.BG_SIDEBAR,
            fg=T.TEXT_PRIMARY,
            font=T.FONT_TREE,
            anchor="w",
            cursor="hand2"
        )
        label.pack(fill=tk.X, padx=5, pady=1)

        label.bind("<Button-1>", lambda e: self._open_file(full_path))
        label.bind("<Enter>", lambda e: label.config(bg=T.BG_EXPLORER_HOVER))
        label.bind("<Leave>", lambda e: label.config(bg=T.BG_SIDEBAR))

    def _open_file(self, filepath):
        """Открыть файл"""
        if self.on_file_open:
            self.on_file_open(filepath)