"""
🖍️ Подсветка синтаксиса Python — как в VS Code
"""

import re
import tkinter as tk
from app.theme import VSCodeTheme


class SyntaxHighlighter:
    """Подсветка синтаксиса для Python"""

    # Паттерны для Python
    PATTERNS = [
        # Комментарии
        (r'#[^\n]*', "comment"),
        # Строки тройные
        (r'"""[\s\S]*?"""', "string"),
        (r"'''[\s\S]*?'''", "string"),
        # Строки обычные
        (r'"[^"\n]*"', "string"),
        (r"'[^'\n]*'", "string"),
        # f-строки
        (r'f"[^"\n]*"', "string"),
        (r"f'[^'\n]*'", "string"),
        # Декораторы
        (r'@\w+', "decorator"),
        # Числа
        (r'\b\d+\.?\d*\b', "number"),
        # import/from
        (r'\b(?:import|from|as)\b', "import"),
        # Ключевые слова
        (r'\b(?:if|elif|else|for|while|break|continue|return|'
         r'def|class|try|except|finally|raise|with|yield|'
         r'lambda|pass|del|global|nonlocal|assert|async|await)\b', "keyword"),
        # Boolean и None
        (r'\b(?:True|False)\b', "boolean"),
        (r'\bNone\b', "none"),
        # self
        (r'\bself\b', "self"),
        # Встроенные функции
        (r'\b(?:print|len|range|int|str|float|list|dict|set|tuple|'
         r'type|isinstance|input|open|super|enumerate|zip|map|filter|'
         r'sorted|reversed|abs|max|min|sum|any|all|hasattr|getattr|'
         r'setattr|property|staticmethod|classmethod)\b', "builtin"),
        # Имя функции после def
        (r'(?<=def\s)\w+', "function"),
        # Имя класса после class
        (r'(?<=class\s)\w+', "class"),
        # Скобки
        (r'[\[\](){}]', "bracket"),
    ]

    def __init__(self, text_widget: tk.Text):
        self.text = text_widget
        self.colors = VSCodeTheme.get_syntax_colors()
        self._setup_tags()

    def _setup_tags(self):
        """Создаёт теги для каждого типа подсветки"""
        for tag_name, color in self.colors.items():
            self.text.tag_configure(
                tag_name,
                foreground=color
            )
        # Приоритет тегов (комментарии и строки важнее)
        self.text.tag_raise("comment")
        self.text.tag_raise("string")

    def highlight_all(self):
        """Подсветить весь текст"""
        # Удаляем все теги
        for tag_name in self.colors:
            self.text.tag_remove(tag_name, "1.0", tk.END)

        # Получаем весь текст
        content = self.text.get("1.0", tk.END)

        # Применяем паттерны
        for pattern, tag_name in self.PATTERNS:
            for match in re.finditer(pattern, content):
                start_idx = f"1.0+{match.start()}c"
                end_idx = f"1.0+{match.end()}c"
                self.text.tag_add(tag_name, start_idx, end_idx)

    def highlight_line(self, line_number: int):
        """Подсветить одну строку"""
        line_start = f"{line_number}.0"
        line_end = f"{line_number}.end"

        # Удаляем теги на этой строке
        for tag_name in self.colors:
            self.text.tag_remove(tag_name, line_start, line_end)

        # Получаем текст строки
        line_content = self.text.get(line_start, line_end)

        # Но для корректности подсвечиваем весь текст
        # (многострочные строки и т.д.)
        self.highlight_all()

    def on_text_changed(self, event=None):
        """Вызывается при изменении текста"""
        self.text.after(50, self.highlight_all)