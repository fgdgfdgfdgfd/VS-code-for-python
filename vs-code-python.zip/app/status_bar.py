"""
📊 Status Bar — нижняя строка как в VS Code
"""

import tkinter as tk
from app.theme import VSCodeTheme as T


class StatusBar(tk.Frame):
    """Нижняя строка состояния VS Code"""

    def __init__(self, parent):
        super().__init__(parent, bg=T.BG_STATUSBAR, height=25)
        self.pack_propagate(False)
        self._create_widgets()

    def _create_widgets(self):
        """Создаём элементы статус бара"""

        # === Левая часть ===
        left_frame = tk.Frame(self, bg=T.BG_STATUSBAR)
        left_frame.pack(side=tk.LEFT, padx=5)

        # 🔀 Ветка Git
        self.branch_label = tk.Label(
            left_frame,
            text="🔀 main",
            bg=T.BG_STATUSBAR,
            fg=T.TEXT_STATUSBAR,
            font=T.FONT_STATUS
        )
        self.branch_label.pack(side=tk.LEFT, padx=(5, 15))

        # ❌ Ошибки  ⚠️ Предупреждения
        self.errors_label = tk.Label(
            left_frame,
            text="❌ 0  ⚠️ 0",
            bg=T.BG_STATUSBAR,
            fg=T.TEXT_STATUSBAR,
            font=T.FONT_STATUS
        )
        self.errors_label.pack(side=tk.LEFT, padx=(0, 15))

        # === Правая часть ===
        right_frame = tk.Frame(self, bg=T.BG_STATUSBAR)
        right_frame.pack(side=tk.RIGHT, padx=5)

        # Позиция курсора
        self.position_label = tk.Label(
            right_frame,
            text="Ln 1, Col 1",
            bg=T.BG_STATUSBAR,
            fg=T.TEXT_STATUSBAR,
            font=T.FONT_STATUS
        )
        self.position_label.pack(side=tk.RIGHT, padx=(15, 5))

        # Кодировка
        self.encoding_label = tk.Label(
            right_frame,
            text="UTF-8",
            bg=T.BG_STATUSBAR,
            fg=T.TEXT_STATUSBAR,
            font=T.FONT_STATUS
        )
        self.encoding_label.pack(side=tk.RIGHT, padx=5)

        # Язык
        self.language_label = tk.Label(
            right_frame,
            text="🐍 Python",
            bg=T.BG_STATUSBAR,
            fg=T.TEXT_STATUSBAR,
            font=T.FONT_STATUS
        )
        self.language_label.pack(side=tk.RIGHT, padx=5)

        # Пробелы/Табы
        self.spaces_label = tk.Label(
            right_frame,
            text="Spaces: 4",
            bg=T.BG_STATUSBAR,
            fg=T.TEXT_STATUSBAR,
            font=T.FONT_STATUS
        )
        self.spaces_label.pack(side=tk.RIGHT, padx=5)

        # Конец строки
        self.eol_label = tk.Label(
            right_frame,
            text="LF",
            bg=T.BG_STATUSBAR,
            fg=T.TEXT_STATUSBAR,
            font=T.FONT_STATUS
        )
        self.eol_label.pack(side=tk.RIGHT, padx=5)

    def update_position(self, line: int, col: int):
        """Обновить позицию курсора"""
        self.position_label.config(text=f"Ln {line}, Col {col}")

    def update_language(self, lang: str):
        """Обновить язык"""
        icons = {
            "Python": "🐍",
            "JavaScript": "📜",
            "HTML": "🌐",
            "CSS": "🎨",
            "JSON": "📋",
            "Text": "📄"
        }
        icon = icons.get(lang, "📄")
        self.language_label.config(text=f"{icon} {lang}")

    def update_errors(self, errors: int, warnings: int):
        """Обновить счётчик ошибок"""
        self.errors_label.config(text=f"❌ {errors}  ⚠️ {warnings}")

    def update_encoding(self, encoding: str):
        """Обновить кодировку"""
        self.encoding_label.config(text=encoding)

    def update_branch(self, branch: str):
        """Обновить ветку Git"""
        self.branch_label.config(text=f"🔀 {branch}")