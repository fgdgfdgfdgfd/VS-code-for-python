"""
📋 Menu Bar — верхнее меню как в VS Code
"""

import tkinter as tk
from app.theme import VSCodeTheme as T


class MenuBar(tk.Frame):
    """Верхнее меню"""

    def __init__(self, parent, callbacks=None):
        super().__init__(parent, bg=T.BG_TITLEBAR, height=30)
        self.pack_propagate(False)

        self.callbacks = callbacks or {}
        self.active_menu = None
        self.menu_windows = []

        self._create_widgets()

    def _create_widgets(self):
        """Создаём меню бар"""

        # Иконка приложения
        icon_label = tk.Label(
            self,
            text=" ⚡ ",
            bg=T.BG_TITLEBAR,
            fg=T.TEXT_ACCENT,
            font=("Segoe UI", 12)
        )
        icon_label.pack(side=tk.LEFT, padx=(5, 0))

        # Пункты меню
        menus = {
            "File": [
                ("📄 New File", "Ctrl+N", "new_file"),
                ("📂 Open File...", "Ctrl+O", "open_file"),
                ("📁 Open Folder...", "Ctrl+K Ctrl+O", "open_folder"),
                ("---", "", ""),
                ("💾 Save", "Ctrl+S", "save"),
                ("💾 Save As...", "Ctrl+Shift+S", "save_as"),
                ("💾 Save All", "Ctrl+K S", "save_all"),
                ("---", "", ""),
                ("🔧 Preferences", "", "preferences"),
                ("---", "", ""),
                ("🚪 Exit", "Alt+F4", "exit"),
            ],
            "Edit": [
                ("↩️ Undo", "Ctrl+Z", "undo"),
                ("↪️ Redo", "Ctrl+Y", "redo"),
                ("---", "", ""),
                ("✂️ Cut", "Ctrl+X", "cut"),
                ("📋 Copy", "Ctrl+C", "copy"),
                ("📌 Paste", "Ctrl+V", "paste"),
                ("---", "", ""),
                ("🔍 Find", "Ctrl+F", "find"),
                ("🔄 Replace", "Ctrl+H", "replace"),
                ("---", "", ""),
                ("💬 Toggle Comment", "Ctrl+/", "toggle_comment"),
            ],
            "View": [
                ("📂 Explorer", "Ctrl+Shift+E", "show_explorer"),
                ("🔍 Search", "Ctrl+Shift+F", "show_search"),
                ("---", "", ""),
                ("💻 Terminal", "Ctrl+`", "toggle_terminal"),
                ("🗺️ Minimap", "", "toggle_minimap"),
                ("---", "", ""),
                ("📏 Word Wrap", "Alt+Z", "word_wrap"),
                ("🔢 Line Numbers", "", "line_numbers"),
            ],
            "Run": [
                ("▶️ Run Python File", "F5", "run_file"),
                ("🐛 Debug", "F9", "debug"),
                ("---", "", ""),
                ("⏹️ Stop", "Shift+F5", "stop"),
            ],
            "Terminal": [
                ("💻 New Terminal", "Ctrl+Shift+`", "new_terminal"),
                ("🗑️ Clear Terminal", "", "clear_terminal"),
            ],
            "Help": [
                ("📖 Documentation", "", "docs"),
                ("⌨️ Keyboard Shortcuts", "Ctrl+K Ctrl+S", "shortcuts"),
                ("---", "", ""),
                ("ℹ️ About", "", "about"),
            ],
        }

        for menu_name, menu_items in menus.items():
            btn = tk.Label(
                self,
                text=f" {menu_name} ",
                bg=T.BG_TITLEBAR,
                fg=T.TEXT_PRIMARY,
                font=("Segoe UI", 10),
                cursor="hand2"
            )
            btn.pack(side=tk.LEFT, padx=0)

            btn.bind("<Button-1>",
                     lambda e, n=menu_name, i=menu_items, b=btn: self._show_menu(b, n, i))
            btn.bind("<Enter>", lambda e, b=btn: b.config(bg=T.BG_HOVER))
            btn.bind("<Leave>", lambda e, b=btn: b.config(bg=T.BG_TITLEBAR))

        # === Правая часть — кнопки управления окном ===
        window_btns = tk.Frame(self, bg=T.BG_TITLEBAR)
        window_btns.pack(side=tk.RIGHT)

        for symbol, action in [("─", "minimize"), ("□", "maximize"), ("✕", "close")]:
            btn = tk.Label(
                window_btns,
                text=f" {symbol} ",
                bg=T.BG_TITLEBAR,
                fg=T.TEXT_PRIMARY,
                font=("Segoe UI", 10),
                cursor="hand2"
            )
            btn.pack(side=tk.LEFT, padx=0)

            if action == "close":
                btn.bind("<Enter>", lambda e, b=btn: b.config(bg="#e81123", fg="white"))
            else:
                btn.bind("<Enter>", lambda e, b=btn: b.config(bg=T.BG_HOVER))

            btn.bind("<Leave>", lambda e, b=btn: b.config(bg=T.BG_TITLEBAR, fg=T.TEXT_PRIMARY))
            btn.bind("<Button-1>", lambda e, a=action: self._window_action(a))

        # Заголовок по центру
        self.title_label = tk.Label(
            self,
            text="VS Code for Python",
            bg=T.BG_TITLEBAR,
            fg=T.TEXT_SECONDARY,
            font=("Segoe UI", 10)
        )
        self.title_label.pack(side=tk.LEFT, expand=True)

    def _show_menu(self, button, name, items):
        """Показать выпадающее меню"""
        self._close_menus()

        menu_win = tk.Toplevel(self)
        menu_win.overrideredirect(True)
        menu_win.config(bg=T.BORDER)

        x = button.winfo_rootx()
        y = button.winfo_rooty() + button.winfo_height()
        menu_win.geometry(f"+{x}+{y}")

        inner = tk.Frame(menu_win, bg=T.BG_MENU, padx=1, pady=4)
        inner.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)

        for label_text, shortcut, action in items:
            if label_text == "---":
                sep = tk.Frame(inner, bg=T.BORDER, height=1)
                sep.pack(fill=tk.X, padx=10, pady=4)
                continue

            item_frame = tk.Frame(inner, bg=T.BG_MENU)
            item_frame.pack(fill=tk.X)

            lbl = tk.Label(
                item_frame,
                text=f"  {label_text}",
                bg=T.BG_MENU,
                fg=T.TEXT_PRIMARY,
                font=("Segoe UI", 10),
                anchor="w",
                cursor="hand2"
            )
            lbl.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5, pady=2)

            if shortcut:
                sc_lbl = tk.Label(
                    item_frame,
                    text=f"{shortcut}  ",
                    bg=T.BG_MENU,
                    fg=T.TEXT_SECONDARY,
                    font=("Segoe UI", 9),
                    anchor="e"
                )
                sc_lbl.pack(side=tk.RIGHT, padx=5, pady=2)

            # Ховер
            for widget in [item_frame, lbl]:
                widget.bind("<Enter>", lambda e, f=item_frame, l=lbl:
                            (f.config(bg=T.BG_SELECTION), l.config(bg=T.BG_SELECTION)))
                widget.bind("<Leave>", lambda e, f=item_frame, l=lbl:
                            (f.config(bg=T.BG_MENU), l.config(bg=T.BG_MENU)))

            # Клик
            if action and action in self.callbacks:
                for widget in [item_frame, lbl]:
                    widget.bind("<Button-1>",
                                lambda e, a=action: (self._close_menus(), self.callbacks[a]()))

        self.menu_windows.append(menu_win)

        # Закрыть при клике вне меню
        menu_win.bind("<FocusOut>", lambda e: self._close_menus())
        menu_win.focus_set()

    def _close_menus(self):
        """Закрыть все меню"""
        for win in self.menu_windows:
            try:
                win.destroy()
            except Exception:
                pass
        self.menu_windows.clear()

    def _window_action(self, action):
        """Действия с окном"""
        root = self.winfo_toplevel()
        if action == "minimize":
            root.iconify()
        elif action == "maximize":
            if root.state() == "zoomed":
                root.state("normal")
            else:
                root.state("zoomed")
        elif action == "close":
            root.quit()

    def update_title(self, filename=""):
        """Обновить заголовок"""
        if filename:
            self.title_label.config(text=f"{filename} — VS Code for Python")
        else:
            self.title_label.config(text="VS Code for Python")