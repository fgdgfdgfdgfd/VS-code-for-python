"""
🔍 Search — поиск по файлам как в VS Code
"""

import tkinter as tk
import os
import re
from app.theme import VSCodeTheme as T


class SearchPanel(tk.Frame):
    """Панель поиска по файлам"""

    def __init__(self, parent, on_result_click=None):
        super().__init__(parent, bg=T.BG_SIDEBAR, width=250)
        self.pack_propagate(False)

        self.on_result_click = on_result_click
        self.search_folder = None

        self._create_widgets()

    def _create_widgets(self):
        """Создаём виджеты"""

        # Заголовок
        header = tk.Frame(self, bg=T.BG_SIDEBAR, height=35)
        header.pack(fill=tk.X)
        header.pack_propagate(False)

        tk.Label(
            header,
            text="  🔍 SEARCH",
            bg=T.BG_SIDEBAR,
            fg=T.TEXT_SECONDARY,
            font=("Segoe UI", 9, "bold"),
            anchor="w"
        ).pack(side=tk.LEFT, padx=10, pady=8)

        # Поле поиска
        search_frame = tk.Frame(self, bg=T.BG_SIDEBAR)
        search_frame.pack(fill=tk.X, padx=10, pady=5)

        self.search_entry = tk.Entry(
            search_frame,
            bg=T.BG_INPUT,
            fg=T.TEXT_PRIMARY,
            insertbackground=T.TEXT_PRIMARY,
            font=T.FONT_UI,
            relief="flat",
            bd=2
        )
        self.search_entry.pack(fill=tk.X, pady=2)
        self.search_entry.insert(0, "🔍 Search...")
        self.search_entry.bind("<FocusIn>", self._on_focus_in)
        self.search_entry.bind("<FocusOut>", self._on_focus_out)
        self.search_entry.bind("<Return>", self._do_search)
        self.search_entry.bind("<KeyRelease>", self._on_key_release)

        # Поле замены
        replace_frame = tk.Frame(self, bg=T.BG_SIDEBAR)
        replace_frame.pack(fill=tk.X, padx=10, pady=2)

        self.replace_entry = tk.Entry(
            replace_frame,
            bg=T.BG_INPUT,
            fg=T.TEXT_PRIMARY,
            insertbackground=T.TEXT_PRIMARY,
            font=T.FONT_UI,
            relief="flat",
            bd=2
        )
        self.replace_entry.pack(fill=tk.X, pady=2)
        self.replace_entry.insert(0, "Replace...")

        # Опции поиска
        options_frame = tk.Frame(self, bg=T.BG_SIDEBAR)
        options_frame.pack(fill=tk.X, padx=10, pady=5)

        self.case_var = tk.BooleanVar(value=False)
        self.regex_var = tk.BooleanVar(value=False)
        self.word_var = tk.BooleanVar(value=False)

        for text, var in [("Aa", self.case_var), (".*", self.regex_var), ("Ab", self.word_var)]:
            btn = tk.Checkbutton(
                options_frame,
                text=text,
                variable=var,
                bg=T.BG_SIDEBAR,
                fg=T.TEXT_SECONDARY,
                selectcolor=T.BG_INPUT,
                font=("Consolas", 10),
                activebackground=T.BG_SIDEBAR,
                activeforeground=T.TEXT_PRIMARY
            )
            btn.pack(side=tk.LEFT, padx=3)

        # Счётчик результатов
        self.results_label = tk.Label(
            self,
            text="",
            bg=T.BG_SIDEBAR,
            fg=T.TEXT_SECONDARY,
            font=T.FONT_UI_SMALL,
            anchor="w"
        )
        self.results_label.pack(fill=tk.X, padx=15, pady=3)

        # Результаты
        results_container = tk.Frame(self, bg=T.BG_SIDEBAR)
        results_container.pack(fill=tk.BOTH, expand=True)

        self.results_canvas = tk.Canvas(
            results_container,
            bg=T.BG_SIDEBAR,
            highlightthickness=0
        )
        self.results_frame = tk.Frame(self.results_canvas, bg=T.BG_SIDEBAR)

        self.results_frame.bind(
            "<Configure>",
            lambda e: self.results_canvas.configure(scrollregion=self.results_canvas.bbox("all"))
        )
        self.results_canvas.create_window((0, 0), window=self.results_frame, anchor="nw")
        self.results_canvas.pack(fill=tk.BOTH, expand=True)

    def set_folder(self, folder_path):
        """Установить папку для поиска"""
        self.search_folder = folder_path

    def _on_focus_in(self, event):
        if self.search_entry.get() == "🔍 Search...":
            self.search_entry.delete(0, tk.END)

    def _on_focus_out(self, event):
        if not self.search_entry.get():
            self.search_entry.insert(0, "🔍 Search...")

    def _on_key_release(self, event):
        """Поиск при вводе (с задержкой)"""
        query = self.search_entry.get()
        if query and query != "🔍 Search..." and len(query) >= 2:
            self.after(300, lambda: self._do_search(None))

    def _do_search(self, event):
        """Выполнить поиск"""
        query = self.search_entry.get()
        if not query or query == "🔍 Search..." or not self.search_folder:
            return

        # Очищаем результаты
        for widget in self.results_frame.winfo_children():
            widget.destroy()

        results = self._search_in_folder(self.search_folder, query)
        total = sum(len(matches) for matches in results.values())
        files_count = len(results)

        self.results_label.config(text=f"  {total} results in {files_count} files")

        # Показываем результаты
        for filepath, matches in results.items():
            filename = os.path.basename(filepath)

            file_label = tk.Label(
                self.results_frame,
                text=f"  📄 {filename} ({len(matches)})",
                bg=T.BG_SIDEBAR,
                fg=T.TEXT_PRIMARY,
                font=("Segoe UI", 10, "bold"),
                anchor="w",
                cursor="hand2"
            )
            file_label.pack(fill=tk.X, padx=5, pady=(5, 0))

            for line_num, line_text in matches[:10]:  # Макс 10 совпадений
                match_label = tk.Label(
                    self.results_frame,
                    text=f"      Ln {line_num}: {line_text.strip()[:60]}",
                    bg=T.BG_SIDEBAR,
                    fg=T.TEXT_SECONDARY,
                    font=T.FONT_UI_SMALL,
                    anchor="w",
                    cursor="hand2"
                )
                match_label.pack(fill=tk.X, padx=5, pady=0)

                match_label.bind(
                    "<Button-1>",
                    lambda e, fp=filepath, ln=line_num: self._click_result(fp, ln)
                )
                match_label.bind("<Enter>", lambda e, l=match_label: l.config(bg=T.BG_HOVER))
                match_label.bind("<Leave>", lambda e, l=match_label: l.config(bg=T.BG_SIDEBAR))

    def _search_in_folder(self, folder, query):
        """Поиск по всем файлам в папке"""
        results = {}
        case_sensitive = self.case_var.get()

        for root, dirs, files in os.walk(folder):
            # Пропускаем скрытые папки
            dirs[:] = [d for d in dirs if not d.startswith('.') and d not in
                       ['__pycache__', 'node_modules', '.git', 'venv']]

            for filename in files:
                filepath = os.path.join(root, filename)
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        lines = f.readlines()

                    matches = []
                    for i, line in enumerate(lines, 1):
                        if case_sensitive:
                            if query in line:
                                matches.append((i, line))
                        else:
                            if query.lower() in line.lower():
                                matches.append((i, line))

                    if matches:
                        results[filepath] = matches

                except (PermissionError, UnicodeDecodeError, IsADirectoryError):
                    continue

        return results

    def _click_result(self, filepath, line_number):
        """Клик по результату поиска"""
        if self.on_result_click:
            self.on_result_click(filepath, line_number)