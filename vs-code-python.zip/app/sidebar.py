"""
📌 Sidebar — боковая панель иконок как в VS Code (левая узкая полоса)
"""

import tkinter as tk
from app.theme import VSCodeTheme as T


class SideBar(tk.Frame):
    """Левая узкая панель с иконками (Activity Bar)"""

    def __init__(self, parent, on_button_click=None):
        super().__init__(parent, bg=T.BG_ACTIVITY, width=48)
        self.pack_propagate(False)
        self.on_button_click = on_button_click
        self.active_button = None
        self.buttons = {}
        self._create_buttons()

    def _create_buttons(self):
        """Создаём кнопки-иконки"""

        icons = [
            ("explorer", "📁", "Explorer"),
            ("search", "🔍", "Search"),
            ("git", "🔀", "Source Control"),
            ("debug", "🐛", "Run and Debug"),
            ("extensions", "🧩", "Extensions"),
        ]

        for btn_id, emoji, tooltip in icons:
            btn = tk.Label(
                self,
                text=emoji,
                bg=T.BG_ACTIVITY,
                fg=T.TEXT_SECONDARY,
                font=("Segoe UI", 18),
                width=3,
                height=1,
                cursor="hand2"
            )
            btn.pack(pady=2, padx=0)

            # Сохраняем
            self.buttons[btn_id] = btn

            # Биндим клик
            btn.bind("<Button-1>", lambda e, b=btn_id: self._on_click(b))
            btn.bind("<Enter>", lambda e, b=btn: self._on_hover(b, True))
            btn.bind("<Leave>", lambda e, b=btn: self._on_hover(b, False))

            # Тултип
            self._create_tooltip(btn, tooltip)

        # Нижние кнопки
        bottom_frame = tk.Frame(self, bg=T.BG_ACTIVITY)
        bottom_frame.pack(side=tk.BOTTOM, pady=5)

        bottom_icons = [
            ("account", "👤", "Account"),
            ("settings", "⚙️", "Settings"),
        ]

        for btn_id, emoji, tooltip in bottom_icons:
            btn = tk.Label(
                bottom_frame,
                text=emoji,
                bg=T.BG_ACTIVITY,
                fg=T.TEXT_SECONDARY,
                font=("Segoe UI", 18),
                width=3,
                height=1,
                cursor="hand2"
            )
            btn.pack(pady=2)
            self.buttons[btn_id] = btn
            btn.bind("<Button-1>", lambda e, b=btn_id: self._on_click(b))
            btn.bind("<Enter>", lambda e, b=btn: self._on_hover(b, True))
            btn.bind("<Leave>", lambda e, b=btn: self._on_hover(b, False))
            self._create_tooltip(btn, tooltip)

        # Активируем Explorer по умолчанию
        self._set_active("explorer")

    def _on_click(self, btn_id):
        """Обработка клика по кнопке"""
        self._set_active(btn_id)
        if self.on_button_click:
            self.on_button_click(btn_id)

    def _set_active(self, btn_id):
        """Установить активную кнопку"""
        # Сбрасываем предыдущую
        if self.active_button and self.active_button in self.buttons:
            self.buttons[self.active_button].config(
                fg=T.TEXT_SECONDARY
            )

        # Устанавливаем новую
        if btn_id in self.buttons:
            self.buttons[btn_id].config(
                fg=T.TEXT_WHITE
            )
            self.active_button = btn_id

    def _on_hover(self, btn, entering):
        """Ховер эффект"""
        if entering:
            btn.config(bg=T.BG_HOVER)
        else:
            btn.config(bg=T.BG_ACTIVITY)

    def _create_tooltip(self, widget, text):
        """Простой тултип"""
        tooltip = None

        def show(event):
            nonlocal tooltip
            x = widget.winfo_rootx() + 55
            y = widget.winfo_rooty()
            tooltip = tk.Toplevel(widget)
            tooltip.wm_overrideredirect(True)
            tooltip.wm_geometry(f"+{x}+{y}")
            label = tk.Label(
                tooltip,
                text=text,
                bg="#252526",
                fg=T.TEXT_PRIMARY,
                font=T.FONT_UI_SMALL,
                padx=8,
                pady=4,
                relief="solid",
                borderwidth=1
            )
            label.pack()

        def hide(event):
            nonlocal tooltip
            if tooltip:
                tooltip.destroy()
                tooltip = None

        widget.bind("<Enter>", lambda e: (show(e), self._on_hover(widget, True)))
        widget.bind("<Leave>", lambda e: (hide(e), self._on_hover(widget, False)))