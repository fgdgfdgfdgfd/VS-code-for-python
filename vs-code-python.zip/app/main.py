"""
🚀 Main — главное окно VS Code for Python
"""

import tkinter as tk
from tkinter import filedialog, messagebox
import os
import sys
import json

# === ФИКС ИМПОРТОВ ===
# Добавляем корневую папку проекта в путь
ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

from app.theme import VSCodeTheme as T
from app.menu_bar import MenuBar
from app.sidebar import SideBar
from app.file_explorer import FileExplorer
from app.search import SearchPanel
from app.tabs import TabBar
from app.editor import CodeEditor
from app.terminal import Terminal
from app.status_bar import StatusBar
from app.welcome import WelcomeTab


class VSCodeApp:
    """Главное приложение VS Code for Python"""

    def __init__(self):
        self.root = tk.Tk()
        self.root.title("VS Code for Python")
        self.root.geometry("1200x700")
        self.root.minsize(800, 500)
        self.root.config(bg=T.BG_DARK)

        self.current_folder = None
        self.current_panel = "explorer"

        self._load_config()
        self._create_layout()
        self._bind_shortcuts()

        # Показываем Welcome
        self._show_welcome()

    def _load_config(self):
        """Загрузить конфиг"""
        config_path = os.path.join(ROOT_DIR, "resources", "config.json")
        try:
            with open(config_path, 'r') as f:
                self.config = json.load(f)
        except Exception:
            self.config = {
                "window_width": 1200,
                "window_height": 700,
                "font_size": 14
            }

    def _create_layout(self):
        """Создаём основной layout"""

        # === 1. Menu Bar (верх) ===
        self.menu_bar = MenuBar(self.root, callbacks={
            "new_file": self.new_file,
            "open_file": self.open_file,
            "open_folder": self.open_folder,
            "save": self.save_file,
            "save_as": self.save_file_as,
            "exit": self.root.quit,
            "undo": self._undo,
            "redo": self._redo,
            "cut": lambda: self.root.focus_get().event_generate("<<Cut>>"),
            "copy": lambda: self.root.focus_get().event_generate("<<Copy>>"),
            "paste": lambda: self.root.focus_get().event_generate("<<Paste>>"),
            "find": self._show_find,
            "toggle_terminal": self._toggle_terminal,
            "toggle_minimap": self._toggle_minimap,
            "show_explorer": lambda: self._show_panel("explorer"),
            "show_search": lambda: self._show_panel("search"),
            "run_file": self.run_file,
            "about": self._show_about,
        })
        self.menu_bar.pack(side=tk.TOP, fill=tk.X)

        # === 2. Status Bar (низ) ===
        self.status_bar = StatusBar(self.root)
        self.status_bar.pack(side=tk.BOTTOM, fill=tk.X)

        # === 3. Terminal (низ, над статус баром) ===
        self.terminal = Terminal(self.root)
        self.terminal.pack(side=tk.BOTTOM, fill=tk.X)

        # === 4. Основная область ===
        main_area = tk.Frame(self.root, bg=T.BG_DARK)
        main_area.pack(fill=tk.BOTH, expand=True)

        # === 4.1 Sidebar (Activity Bar) ===
        self.sidebar = SideBar(main_area, on_button_click=self._on_sidebar_click)
        self.sidebar.pack(side=tk.LEFT, fill=tk.Y)

        # === 4.2 Панели (Explorer / Search) ===
        self.panels_frame = tk.Frame(main_area, bg=T.BG_SIDEBAR, width=250)
        self.panels_frame.pack(side=tk.LEFT, fill=tk.Y)
        self.panels_frame.pack_propagate(False)

        # File Explorer
        self.file_explorer = FileExplorer(
            self.panels_frame,
            on_file_open=self._on_file_open
        )

        # Search Panel
        self.search_panel = SearchPanel(
            self.panels_frame,
            on_result_click=self._on_search_result
        )

        # Показываем Explorer по умолчанию
        self.file_explorer.pack(fill=tk.BOTH, expand=True)

        # === 4.3 Редактор ===
        editor_area = tk.Frame(main_area, bg=T.BG_DARK)
        editor_area.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Tab Bar
        self.tab_bar = TabBar(
            editor_area,
            on_tab_select=self._on_tab_select,
            on_tab_close=self._on_tab_close
        )
        self.tab_bar.pack(side=tk.TOP, fill=tk.X)

        # Editor Frame
        self.editor_frame = tk.Frame(editor_area, bg=T.BG_DARK)
        self.editor_frame.pack(fill=tk.BOTH, expand=True)

        # Code Editor
        self.editor = CodeEditor(self.editor_frame, status_bar=self.status_bar)

        # Welcome Tab
        self.welcome = WelcomeTab(
            self.editor_frame,
            on_open_folder=self.open_folder,
            on_open_file=self.open_file,
            on_new_file=self.new_file
        )

    def _bind_shortcuts(self):
        """Горячие клавиши"""
        self.root.bind("<Control-n>", lambda e: self.new_file())
        self.root.bind("<Control-o>", lambda e: self.open_file())
        self.root.bind("<Control-s>", lambda e: self.save_file())
        self.root.bind("<Control-Shift-S>", lambda e: self.save_file_as())
        self.root.bind("<Control-grave>", lambda e: self._toggle_terminal())
        self.root.bind("<F5>", lambda e: self.run_file())
        self.root.bind("<Control-Shift-E>", lambda e: self._show_panel("explorer"))
        self.root.bind("<Control-Shift-F>", lambda e: self._show_panel("search"))
        self.root.bind("<Control-f>", lambda e: self._show_find())
        self.root.bind("<Control-Shift-P>", lambda e: self._command_palette())

    # === Безопасные undo/redo ===
    def _undo(self):
        try:
            self.editor.text.edit_undo()
        except tk.TclError:
            pass

    def _redo(self):
        try:
            self.editor.text.edit_redo()
        except tk.TclError:
            pass

    # === Действия с файлами ===

    def new_file(self):
        """Новый файл"""
        filepath = "untitled-1.py"
        counter = 1
        while filepath in self.editor.file_contents:
            counter += 1
            filepath = f"untitled-{counter}.py"

        self.editor.file_contents[filepath] = ""
        self._hide_welcome()
        self.editor.pack(fill=tk.BOTH, expand=True)
        self.tab_bar.add_tab(filepath)
        self.editor.current_file = filepath
        self.editor.text.delete("1.0", tk.END)
        self.editor._update_line_numbers()
        self.menu_bar.update_title(filepath)

    def open_file(self):
        """Открыть файл"""
        filepath = filedialog.askopenfilename(
            filetypes=[
                ("Python Files", "*.py"),
                ("All Files", "*.*"),
                ("JavaScript", "*.js"),
                ("HTML", "*.html"),
                ("CSS", "*.css"),
                ("JSON", "*.json"),
                ("Markdown", "*.md"),
                ("Text", "*.txt"),
            ]
        )
        if filepath:
            self._on_file_open(filepath)

    def open_folder(self):
        """Открыть папку"""
        folder = filedialog.askdirectory()
        if folder:
            self.current_folder = folder
            self.file_explorer.open_folder(folder)
            self.search_panel.set_folder(folder)
            self.terminal.cwd = folder
            self.menu_bar.update_title(os.path.basename(folder))

    def save_file(self):
        """Сохранить файл"""
        if self.editor.current_file and self.editor.current_file.startswith("untitled"):
            self.save_file_as()
        elif self.editor.current_file:
            if self.editor.save_file():
                self.tab_bar.set_modified(self.editor.current_file, False)

    def save_file_as(self):
        """Сохранить как"""
        filepath = filedialog.asksaveasfilename(
            defaultextension=".py",
            filetypes=[
                ("Python Files", "*.py"),
                ("All Files", "*.*"),
            ]
        )
        if filepath:
            self.editor.save_file(filepath)
            self.menu_bar.update_title(os.path.basename(filepath))

    def run_file(self):
        """Запустить Python файл"""
        if self.editor.current_file:
            self.save_file()
            if not self.terminal.visible:
                self.terminal.toggle()
            self.terminal.run_file(self.editor.current_file)

    # === Панели ===

    def _on_sidebar_click(self, btn_id):
        if btn_id == "explorer":
            self._show_panel("explorer")
        elif btn_id == "search":
            self._show_panel("search")
        elif btn_id == "settings":
            self._show_about()

    def _show_panel(self, panel_name):
        self.file_explorer.pack_forget()
        self.search_panel.pack_forget()

        if panel_name == "explorer":
            self.file_explorer.pack(fill=tk.BOTH, expand=True)
        elif panel_name == "search":
            self.search_panel.pack(fill=tk.BOTH, expand=True)

        self.current_panel = panel_name

    # === Файлы и вкладки ===

    def _on_file_open(self, filepath):
        if not os.path.isfile(filepath):
            return

        self._hide_welcome()
        self.editor.pack(fill=tk.BOTH, expand=True)
        self.tab_bar.add_tab(filepath)
        self.editor.open_file(filepath)
        self.menu_bar.update_title(os.path.basename(filepath))

    def _on_tab_select(self, filepath):
        self.editor.open_file(filepath)
        self.menu_bar.update_title(os.path.basename(filepath))

    def _on_tab_close(self, filepath):
        if filepath in self.editor.file_contents:
            del self.editor.file_contents[filepath]

        if not self.tab_bar.tabs:
            self.editor.pack_forget()
            self._show_welcome()

    def _on_search_result(self, filepath, line_number):
        self._on_file_open(filepath)
        self.editor.goto_line(line_number)

    # === UI ===

    def _show_welcome(self):
        self.editor.pack_forget()
        self.welcome.pack(fill=tk.BOTH, expand=True)

    def _hide_welcome(self):
        self.welcome.pack_forget()

    def _toggle_terminal(self):
        self.terminal.toggle()

    def _toggle_minimap(self):
        self.editor.minimap.toggle()

    def _show_find(self):
        self._show_panel("search")
        self.sidebar._set_active("search")

    def _command_palette(self):
        palette = tk.Toplevel(self.root)
        palette.title("")
        palette.overrideredirect(True)
        palette.config(bg=T.BORDER)

        w = 500
        h = 40
        x = self.root.winfo_x() + (self.root.winfo_width() - w) // 2
        y = self.root.winfo_y() + 50
        palette.geometry(f"{w}x{h}+{x}+{y}")

        inner = tk.Frame(palette, bg=T.BG_INPUT, padx=1, pady=1)
        inner.pack(fill=tk.BOTH, expand=True, padx=1, pady=1)

        entry = tk.Entry(
            inner,
            bg=T.BG_INPUT,
            fg=T.TEXT_PRIMARY,
            insertbackground=T.TEXT_PRIMARY,
            font=("Segoe UI", 13),
            relief="flat",
            bd=5
        )
        entry.pack(fill=tk.BOTH, expand=True)
        entry.insert(0, "> ")
        entry.focus_set()
        entry.icursor(2)

        entry.bind("<Escape>", lambda e: palette.destroy())
        entry.bind("<FocusOut>", lambda e: palette.destroy())

    def _show_about(self):
        messagebox.showinfo(
            "About VS Code for Python",
            "⚡ VS Code for Python\n"
            "Version 1.0.0\n\n"
            "🐍 Built with Python & Tkinter\n"
            "📦 Clone of Visual Studio Code\n\n"
            "Made with ❤️"
        )

    def run(self):
        """Запуск приложения"""
        self.root.mainloop()


# === Точка входа ===
if __name__ == "__main__":
    app = VSCodeApp()
    app.run()