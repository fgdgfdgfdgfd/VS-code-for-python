"""
📝 Editor — главный редактор кода как в VS Code
"""

import tkinter as tk
import os
from app.theme import VSCodeTheme as T
from app.syntax import SyntaxHighlighter
from app.minimap import Minimap


class CodeEditor(tk.Frame):
    """Редактор кода с номерами строк и подсветкой"""

    def __init__(self, parent, status_bar=None):
        super().__init__(parent, bg=T.BG_DARK)

        self.status_bar = status_bar
        self.current_file = None
        self.file_contents = {}  # {filepath: content}
        self.highlighter = None
        self.undo_stack = []
        self.redo_stack = []

        self._create_widgets()
        self._bind_events()

    def _create_widgets(self):
        """Создаём виджеты редактора"""

        # Основной контейнер
        editor_container = tk.Frame(self, bg=T.BG_DARK)
        editor_container.pack(fill=tk.BOTH, expand=True)

        # === Номера строк ===
        self.line_numbers = tk.Text(
            editor_container,
            bg="#1e1e1e",
            fg=T.TEXT_SECONDARY,
            font=T.FONT_CODE,
            width=5,
            padx=8,
            pady=8,
            relief="flat",
            state="disabled",
            cursor="arrow",
            selectbackground="#1e1e1e",
            selectforeground=T.TEXT_SECONDARY,
            highlightthickness=0,
            bd=0
        )
        self.line_numbers.pack(side=tk.LEFT, fill=tk.Y)

        # === Текстовый редактор ===
        text_frame = tk.Frame(editor_container, bg=T.BG_DARK)
        text_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.text = tk.Text(
            text_frame,
            bg=T.BG_DARK,
            fg=T.TEXT_PRIMARY,
            font=T.FONT_CODE,
            insertbackground="#aeafad",
            insertwidth=2,
            selectbackground=T.BG_SELECTION,
            selectforeground="",
            relief="flat",
            wrap=tk.NONE,
            undo=True,
            autoseparators=True,
            maxundo=-1,
            padx=5,
            pady=8,
            tabs="4c",
            highlightthickness=0,
            bd=0
        )
        self.text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        # Скроллбар вертикальный
        self.v_scroll = tk.Scrollbar(
            text_frame,
            orient=tk.VERTICAL,
            command=self._on_scroll,
            bg=T.BG_SCROLLBAR,
            troughcolor=T.BG_DARK,
            width=12,
            elementborderwidth=0
        )
        self.v_scroll.pack(side=tk.RIGHT, fill=tk.Y)

        # Скроллбар горизонтальный
        self.h_scroll = tk.Scrollbar(
            self,
            orient=tk.HORIZONTAL,
            command=self.text.xview,
            bg=T.BG_SCROLLBAR,
            troughcolor=T.BG_DARK,
            width=12,
            elementborderwidth=0
        )
        self.h_scroll.pack(side=tk.BOTTOM, fill=tk.X)

        self.text.config(
            yscrollcommand=self._on_text_scroll,
            xscrollcommand=self.h_scroll.set
        )

        # === Мини-карта ===
        self.minimap = Minimap(editor_container, text_widget=self.text)
        self.minimap.pack(side=tk.RIGHT, fill=tk.Y)

        # Подсветка синтаксиса
        self.highlighter = SyntaxHighlighter(self.text)

        # Подсветка текущей строки
        self.text.tag_configure(
            "current_line",
            background=T.BG_LINE_HIGHLIGHT
        )

        # Подсветка текущего номера строки
        self.line_numbers.tag_configure(
            "current_line_num",
            foreground=T.TEXT_PRIMARY
        )

    def _bind_events(self):
        """Биндим события"""
        self.text.bind("<KeyRelease>", self._on_key_release)
        self.text.bind("<ButtonRelease-1>", self._on_click)
        self.text.bind("<Tab>", self._on_tab)
        self.text.bind("<Shift-Tab>", self._on_shift_tab)
        self.text.bind("<Control-d>", self._duplicate_line)
        self.text.bind("<Control-slash>", self._toggle_comment)
        self.text.bind("<Control-BackSpace>", self._delete_word)
        self.text.bind("<Return>", self._on_enter)
        self.text.bind("<BackSpace>", self._on_backspace)

        # Авто-скобки
        self.text.bind("<(>", lambda e: self._auto_pair("(", ")"))
        self.text.bind("<[>", lambda e: self._auto_pair("[", "]"))
        self.text.bind("<braceleft>", lambda e: self._auto_pair("{", "}"))
        self.text.bind("<quotedbl>", lambda e: self._auto_pair('"', '"'))
        self.text.bind("<quoteright>", lambda e: self._auto_pair("'", "'"))

    def open_file(self, filepath):
        """Открыть файл"""
        if not os.path.isfile(filepath):
            return

        # Сохраняем текущий контент
        if self.current_file:
            self.file_contents[self.current_file] = self.text.get("1.0", tk.END)

        # Загружаем файл
        if filepath in self.file_contents:
            content = self.file_contents[filepath]
        else:
            try:
                with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
                    content = f.read()
                self.file_contents[filepath] = content
            except Exception as ex:
                content = f"❌ Error opening file: {ex}"

        self.current_file = filepath

        # Вставляем текст
        self.text.config(state="normal")
        self.text.delete("1.0", tk.END)
        self.text.insert("1.0", content.rstrip("\n"))

        # Обновляем
        self._update_line_numbers()
        self.highlighter.highlight_all()
        self._update_minimap()
        self._highlight_current_line()
        self._update_status_bar()

        # Определяем язык
        ext = os.path.splitext(filepath)[1].lower()
        lang_map = {
            ".py": "Python", ".js": "JavaScript", ".html": "HTML",
            ".css": "CSS", ".json": "JSON", ".md": "Markdown",
            ".txt": "Plain Text", ".xml": "XML",
        }
        if self.status_bar:
            lang = lang_map.get(ext, "Plain Text")
            self.status_bar.update_language(lang)

    def save_file(self, filepath=None):
        """Сохранить файл"""
        if filepath is None:
            filepath = self.current_file
        if filepath is None:
            return False

        try:
            content = self.text.get("1.0", "end-1c")
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)
            self.file_contents[filepath] = content
            return True
        except Exception as ex:
            print(f"❌ Error saving: {ex}")
            return False

    def get_content(self):
        """Получить текущий контент"""
        return self.text.get("1.0", "end-1c")

    def _on_key_release(self, event):
        """При нажатии клавиши"""
        self._update_line_numbers()
        self._highlight_current_line()
        self._update_status_bar()
        self.highlighter.on_text_changed()

        # Обновляем миникарту с задержкой
        self.after(500, self._update_minimap)

    def _on_click(self, event):
        """При клике мышью"""
        self._highlight_current_line()
        self._update_status_bar()

    def _on_scroll(self, *args):
        """При скролле"""
        self.text.yview(*args)
        self.line_numbers.yview(*args)

    def _on_text_scroll(self, *args):
        """Синхронизация скролла"""
        self.v_scroll.set(*args)
        self.line_numbers.yview_moveto(args[0])
        self.after(100, lambda: self.minimap._draw_viewport())

    def _update_line_numbers(self):
        """Обновить номера строк"""
        self.line_numbers.config(state="normal")
        self.line_numbers.delete("1.0", tk.END)

        line_count = int(self.text.index("end-1c").split(".")[0])
        line_numbers_text = "\n".join(str(i) for i in range(1, line_count + 1))
        self.line_numbers.insert("1.0", line_numbers_text)

        self.line_numbers.config(state="disabled")

    def _highlight_current_line(self):
        """Подсветить текущую строку"""
        self.text.tag_remove("current_line", "1.0", tk.END)

        current = self.text.index(tk.INSERT)
        line = current.split(".")[0]
        self.text.tag_add("current_line", f"{line}.0", f"{line}.end+1c")

    def _update_status_bar(self):
        """Обновить статус бар"""
        if not self.status_bar:
            return
        cursor = self.text.index(tk.INSERT)
        line, col = cursor.split(".")
        self.status_bar.update_position(int(line), int(col) + 1)

    def _update_minimap(self):
        """Обновить мини-карту"""
        content = self.text.get("1.0", "end-1c")
        self.minimap.update_minimap(content)

    def _on_tab(self, event):
        """Вставить 4 пробела вместо таба"""
        self.text.insert(tk.INSERT, "    ")
        return "break"

    def _on_shift_tab(self, event):
        """Убрать отступ"""
        line = self.text.index(tk.INSERT).split(".")[0]
        line_text = self.text.get(f"{line}.0", f"{line}.end")
        if line_text.startswith("    "):
            self.text.delete(f"{line}.0", f"{line}.4")
        return "break"

    def _on_enter(self, event):
        """Умный Enter — автоотступ"""
        cursor = self.text.index(tk.INSERT)
        line = cursor.split(".")[0]
        current_line = self.text.get(f"{line}.0", f"{line}.end")

        # Считаем текущий отступ
        indent = len(current_line) - len(current_line.lstrip())
        new_indent = " " * indent

        # Увеличиваем отступ после :
        stripped = current_line.rstrip()
        if stripped.endswith(":"):
            new_indent += "    "

        self.text.insert(tk.INSERT, "\n" + new_indent)
        self._update_line_numbers()
        self._highlight_current_line()
        return "break"

    def _on_backspace(self, event):
        """Умный Backspace — удаляет 4 пробела"""
        cursor = self.text.index(tk.INSERT)
        line, col = cursor.split(".")
        col = int(col)

        if col >= 4:
            before = self.text.get(f"{line}.{col-4}", f"{line}.{col}")
            if before == "    ":
                self.text.delete(f"{line}.{col-4}", f"{line}.{col}")
                return "break"
        return None

    def _auto_pair(self, open_char, close_char):
        """Автозакрытие скобок и кавычек"""
        self.text.insert(tk.INSERT, open_char + close_char)
        # Курсор между скобками
        cursor = self.text.index(tk.INSERT)
        line, col = cursor.split(".")
        self.text.mark_set(tk.INSERT, f"{line}.{int(col)-1}")
        return "break"

    def _duplicate_line(self, event):
        """Ctrl+D — дублировать строку"""
        cursor = self.text.index(tk.INSERT)
        line = cursor.split(".")[0]
        line_text = self.text.get(f"{line}.0", f"{line}.end")
        self.text.insert(f"{line}.end", "\n" + line_text)
        self._update_line_numbers()
        return "break"

    def _toggle_comment(self, event):
        """Ctrl+/ — закомментировать строку"""
        cursor = self.text.index(tk.INSERT)
        line = cursor.split(".")[0]
        line_text = self.text.get(f"{line}.0", f"{line}.end")

        if line_text.lstrip().startswith("# "):
            # Раскомментировать
            idx = line_text.index("# ")
            self.text.delete(f"{line}.{idx}", f"{line}.{idx+2}")
        else:
            # Закомментировать
            indent = len(line_text) - len(line_text.lstrip())
            self.text.insert(f"{line}.{indent}", "# ")

        self.highlighter.highlight_all()
        return "break"

    def _delete_word(self, event):
        """Ctrl+Backspace — удалить слово"""
        self.text.delete("insert-1c wordstart", "insert")
        return "break"

    def goto_line(self, line_number):
        """Перейти к строке"""
        self.text.see(f"{line_number}.0")
        self.text.mark_set(tk.INSERT, f"{line_number}.0")
        self._highlight_current_line()
        self._update_status_bar()