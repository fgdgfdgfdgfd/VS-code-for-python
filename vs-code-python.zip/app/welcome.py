"""
🏠 Welcome Tab — стартовая страница как в VS Code
"""

import tkinter as tk
from app.theme import VSCodeTheme as T


class WelcomeTab(tk.Frame):
    """Welcome страница"""

    def __init__(self, parent, on_open_folder=None, on_open_file=None,
                 on_new_file=None):
        super().__init__(parent, bg=T.BG_WELCOME)

        self.on_open_folder = on_open_folder
        self.on_open_file = on_open_file
        self.on_new_file = on_new_file

        self._create_widgets()

    def _create_widgets(self):
        """Создаём Welcome страницу"""

        # Центральный контейнер
        center = tk.Frame(self, bg=T.BG_WELCOME)
        center.place(relx=0.5, rely=0.4, anchor="center")

        # Логотип
        logo = tk.Label(
            center,
            text="⚡",
            bg=T.BG_WELCOME,
            fg=T.TEXT_ACCENT,
            font=("Segoe UI", 64)
        )
        logo.pack(pady=(0, 10))

        # Название
        title = tk.Label(
            center,
            text="VS Code for Python",
            bg=T.BG_WELCOME,
            fg=T.TEXT_PRIMARY,
            font=T.FONT_WELCOME_TITLE
        )
        title.pack(pady=(0, 5))

        # Подзаголовок
        subtitle = tk.Label(
            center,
            text="Editing evolved",
            bg=T.BG_WELCOME,
            fg=T.TEXT_SECONDARY,
            font=("Segoe UI", 14)
        )
        subtitle.pack(pady=(0, 30))

        # === Start секция ===
        start_frame = tk.Frame(center, bg=T.BG_WELCOME)
        start_frame.pack(anchor="w", pady=(0, 20))

        tk.Label(
            start_frame,
            text="Start",
            bg=T.BG_WELCOME,
            fg=T.TEXT_PRIMARY,
            font=("Segoe UI", 14, "bold")
        ).pack(anchor="w", pady=(0, 8))

        start_items = [
            ("📄  New File", self._new_file, "Ctrl+N"),
            ("📂  Open File...", self._open_file, "Ctrl+O"),
            ("📁  Open Folder...", self._open_folder, "Ctrl+K Ctrl+O"),
            ("🔄  Clone Git Repository...", None, ""),
        ]

        for text, command, shortcut in start_items:
            item_frame = tk.Frame(start_frame, bg=T.BG_WELCOME)
            item_frame.pack(fill=tk.X, pady=2)

            link = tk.Label(
                item_frame,
                text=text,
                bg=T.BG_WELCOME,
                fg=T.TEXT_ACCENT,
                font=T.FONT_WELCOME,
                cursor="hand2"
            )
            link.pack(side=tk.LEFT)

            if shortcut:
                tk.Label(
                    item_frame,
                    text=f"  {shortcut}",
                    bg=T.BG_WELCOME,
                    fg=T.TEXT_SECONDARY,
                    font=T.FONT_UI_SMALL
                ).pack(side=tk.LEFT, padx=(10, 0))

            if command:
                link.bind("<Button-1>", lambda e, c=command: c())
                link.bind("<Enter>", lambda e, l=link: l.config(fg="#3794ff"))
                link.bind("<Leave>", lambda e, l=link: l.config(fg=T.TEXT_ACCENT))

        # === Recent секция ===
        recent_frame = tk.Frame(center, bg=T.BG_WELCOME)
        recent_frame.pack(anchor="w", pady=(0, 20))

        tk.Label(
            recent_frame,
            text="Recent",
            bg=T.BG_WELCOME,
            fg=T.TEXT_PRIMARY,
            font=("Segoe UI", 14, "bold")
        ).pack(anchor="w", pady=(0, 8))

        tk.Label(
            recent_frame,
            text="📋  No recent files",
            bg=T.BG_WELCOME,
            fg=T.TEXT_SECONDARY,
            font=T.FONT_WELCOME
        ).pack(anchor="w")

        # === Help секция ===
        help_frame = tk.Frame(center, bg=T.BG_WELCOME)
        help_frame.pack(anchor="w", pady=(0, 20))

        tk.Label(
            help_frame,
            text="Help",
            bg=T.BG_WELCOME,
            fg=T.TEXT_PRIMARY,
            font=("Segoe UI", 14, "bold")
        ).pack(anchor="w", pady=(0, 8))

        help_items = [
            "📖  Documentation",
            "⌨️  Keyboard Shortcuts",
            "🎬  Introductory Videos",
            "💡  Tips and Tricks",
        ]

        for text in help_items:
            lbl = tk.Label(
                help_frame,
                text=text,
                bg=T.BG_WELCOME,
                fg=T.TEXT_ACCENT,
                font=T.FONT_WELCOME,
                cursor="hand2"
            )
            lbl.pack(anchor="w", pady=2)
            lbl.bind("<Enter>", lambda e, l=lbl: l.config(fg="#3794ff"))
            lbl.bind("<Leave>", lambda e, l=lbl: l.config(fg=T.TEXT_ACCENT))

        # Нижняя строка
        bottom = tk.Label(
            self,
            text="🐍 Made with Python  |  v1.0.0",
            bg=T.BG_WELCOME,
            fg=T.TEXT_SECONDARY,
            font=T.FONT_UI_SMALL
        )
        bottom.place(relx=0.5, rely=0.95, anchor="center")

    def _new_file(self):
        if self.on_new_file:
            self.on_new_file()

    def _open_file(self):
        if self.on_open_file:
            self.on_open_file()

    def _open_folder(self):
        if self.on_open_folder:
            self.on_open_folder()