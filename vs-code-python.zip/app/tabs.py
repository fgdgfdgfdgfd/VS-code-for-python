"""
📑 Tabs — система вкладок как в VS Code
"""

import tkinter as tk
import os
from app.theme import VSCodeTheme as T


class TabBar(tk.Frame):
    """Панель вкладок"""

    def __init__(self, parent, on_tab_select=None, on_tab_close=None):
        super().__init__(parent, bg=T.BG_TAB_INACTIVE, height=35)
        self.pack_propagate(False)

        self.tabs = {}  # {filepath: tab_frame}
        self.active_tab = None
        self.on_tab_select = on_tab_select
        self.on_tab_close = on_tab_close

        # Скролл контейнер для вкладок
        self.tabs_container = tk.Frame(self, bg=T.BG_TAB_INACTIVE)
        self.tabs_container.pack(side=tk.LEFT, fill=tk.Y)

    def add_tab(self, filepath, modified=False):
        """Добавить вкладку"""
        if filepath in self.tabs:
            self.select_tab(filepath)
            return

        # Определяем иконку по расширению
        ext = os.path.splitext(filepath)[1].lower()
        icons = {
            ".py": "🐍",
            ".js": "📜",
            ".html": "🌐",
            ".css": "🎨",
            ".json": "📋",
            ".md": "📝",
            ".txt": "📄",
            ".xml": "📰",
            ".yml": "⚙️",
            ".yaml": "⚙️",
            ".ini": "🔧",
            ".cfg": "🔧",
            ".gitignore": "🔀",
        }
        icon = icons.get(ext, "📄")
        filename = os.path.basename(filepath)

        # Создаём фрейм вкладки
        tab_frame = tk.Frame(
            self.tabs_container,
            bg=T.BG_TAB_INACTIVE,
            padx=0,
            pady=0
        )
        tab_frame.pack(side=tk.LEFT, padx=0)

        # Иконка + имя файла
        name_label = tk.Label(
            tab_frame,
            text=f" {icon} {filename} ",
            bg=T.BG_TAB_INACTIVE,
            fg=T.TEXT_INACTIVE,
            font=T.FONT_TAB,
            cursor="hand2"
        )
        name_label.pack(side=tk.LEFT, padx=(8, 0))

        # Кнопка закрытия ✕
        close_btn = tk.Label(
            tab_frame,
            text=" ✕ ",
            bg=T.BG_TAB_INACTIVE,
            fg=T.TEXT_SECONDARY,
            font=("Segoe UI", 9),
            cursor="hand2"
        )
        close_btn.pack(side=tk.LEFT, padx=(0, 5))

        # Нижняя граница (индикатор активности)
        border = tk.Frame(tab_frame, bg=T.BG_TAB_INACTIVE, height=2)
        border.pack(side=tk.BOTTOM, fill=tk.X)

        # Сохраняем
        self.tabs[filepath] = {
            "frame": tab_frame,
            "label": name_label,
            "close": close_btn,
            "border": border,
            "modified": modified
        }

        # Биндим события
        name_label.bind("<Button-1>", lambda e, fp=filepath: self.select_tab(fp))
        close_btn.bind("<Button-1>", lambda e, fp=filepath: self.close_tab(fp))
        close_btn.bind("<Enter>", lambda e: close_btn.config(bg=T.BG_HOVER, fg="red"))
        close_btn.bind("<Leave>", lambda e, fp=filepath: self._reset_close_btn(fp))

        tab_frame.bind("<Enter>", lambda e, fp=filepath: self._hover_tab(fp, True))
        tab_frame.bind("<Leave>", lambda e, fp=filepath: self._hover_tab(fp, False))

        # Активируем
        self.select_tab(filepath)

    def select_tab(self, filepath):
        """Выбрать вкладку"""
        if filepath not in self.tabs:
            return

        # Деактивируем предыдущую
        if self.active_tab and self.active_tab in self.tabs:
            tab = self.tabs[self.active_tab]
            tab["frame"].config(bg=T.BG_TAB_INACTIVE)
            tab["label"].config(bg=T.BG_TAB_INACTIVE, fg=T.TEXT_INACTIVE)
            tab["close"].config(bg=T.BG_TAB_INACTIVE)
            tab["border"].config(bg=T.BG_TAB_INACTIVE)

        # Активируем новую
        tab = self.tabs[filepath]
        tab["frame"].config(bg=T.BG_TAB_ACTIVE)
        tab["label"].config(bg=T.BG_TAB_ACTIVE, fg=T.TEXT_PRIMARY)
        tab["close"].config(bg=T.BG_TAB_ACTIVE)
        tab["border"].config(bg=T.BORDER_ACTIVE)

        self.active_tab = filepath

        if self.on_tab_select:
            self.on_tab_select(filepath)

    def close_tab(self, filepath):
        """Закрыть вкладку"""
        if filepath not in self.tabs:
            return

        tab = self.tabs[filepath]
        tab["frame"].destroy()
        del self.tabs[filepath]

        # Выбираем другую вкладку
        if self.active_tab == filepath:
            self.active_tab = None
            if self.tabs:
                last_tab = list(self.tabs.keys())[-1]
                self.select_tab(last_tab)

        if self.on_tab_close:
            self.on_tab_close(filepath)

    def set_modified(self, filepath, modified=True):
        """Отметить файл как изменённый"""
        if filepath in self.tabs:
            tab = self.tabs[filepath]
            tab["modified"] = modified
            label_text = tab["label"].cget("text").rstrip(" ●")
            if modified:
                tab["label"].config(text=label_text + " ●")
            else:
                tab["label"].config(text=label_text)

    def _hover_tab(self, filepath, entering):
        """Ховер эффект"""
        if filepath == self.active_tab:
            return
        if filepath in self.tabs:
            bg = T.BG_HOVER if entering else T.BG_TAB_INACTIVE
            tab = self.tabs[filepath]
            tab["frame"].config(bg=bg)
            tab["label"].config(bg=bg)
            tab["close"].config(bg=bg)

    def _reset_close_btn(self, filepath):
        """Сброс кнопки закрытия"""
        if filepath in self.tabs:
            tab = self.tabs[filepath]
            bg = T.BG_TAB_ACTIVE if filepath == self.active_tab else T.BG_TAB_INACTIVE
            tab["close"].config(bg=bg, fg=T.TEXT_SECONDARY)